package com.example.fooddelivery;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class CartActivity extends AppCompatActivity {

    TextView data, total;
    DBHelper db;
    Button checkout;
    int sum = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_cart);

        data = findViewById(R.id.cartData);
        total = findViewById(R.id.total);
        checkout = findViewById(R.id.btnCheckout);

        db = new DBHelper(this);

        Cursor c = db.getCart();
        StringBuilder sb = new StringBuilder();

        while (c.moveToNext()) {
            int price = c.getInt(1);
            int qty = c.getInt(2);

            sum += price * qty;

            sb.append(c.getString(0))
                    .append(" x ").append(qty)
                    .append(" = ₹").append(price * qty)
                    .append("\n");
        }

        c.close();

        data.setText(sb.toString());
        total.setText("Total: ₹" + sum);

        checkout.setOnClickListener(v ->
                startActivity(new Intent(this, CheckoutActivity.class))
        );
    }
}
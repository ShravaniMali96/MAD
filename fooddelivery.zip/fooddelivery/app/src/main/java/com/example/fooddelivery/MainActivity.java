package com.example.fooddelivery;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    TextView btnCart;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        btnCart = findViewById(R.id.btnCart);

        db = new DBHelper(this);

        List<FoodItem> list = new ArrayList<>();
        list.add(new FoodItem("Pizza", 200));
        list.add(new FoodItem("Burger", 120));
        list.add(new FoodItem("Pasta", 180));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new FoodAdapter(list, this, db));

        btnCart.setOnClickListener(v ->
                startActivity(new Intent(this, CartActivity.class))
        );

        updateCart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCart();
    }

    private void updateCart() {
        btnCart.setText("Cart 🛒 (" + db.getCount() + ")");
    }
}
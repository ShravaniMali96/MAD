package com.example.fooddelivery;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class CheckoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_checkout);

        EditText name = findViewById(R.id.etName);
        EditText address = findViewById(R.id.etAddress);

        findViewById(R.id.placeOrder).setOnClickListener(v -> {

            if (name.getText().toString().isEmpty() ||
                    address.getText().toString().isEmpty()) {

                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();

            } else {
                startActivity(new Intent(this, OrderSuccessActivity.class));
            }
        });
    }
}
package com.example.fooddelivery;

import android.content.Context;
import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import java.util.*;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.ViewHolder> {

    List<FoodItem> list;
    Context context;
    DBHelper db;

    public FoodAdapter(List<FoodItem> list, Context context, DBHelper db) {
        this.list = list;
        this.context = context;
        this.db = db;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, price;
        Button add;

        public ViewHolder(View v) {
            super(v);
            name = v.findViewById(R.id.foodName);
            price = v.findViewById(R.id.foodPrice);
            add = v.findViewById(R.id.addBtn);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.food_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder h, int p) {
        FoodItem item = list.get(p);

        h.name.setText(item.name);
        h.price.setText("₹" + item.price);

        h.add.setOnClickListener(v -> {
            db.addToCart(item.name, item.price);
            Toast.makeText(context, "Added", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
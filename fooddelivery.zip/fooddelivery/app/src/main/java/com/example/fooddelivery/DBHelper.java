package com.example.fooddelivery;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "FoodDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE cart(name TEXT PRIMARY KEY, price INTEGER, qty INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS cart");
        onCreate(db);
    }

    public void addToCart(String name, int price) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM cart WHERE name=?", new String[]{name});

        if (c.moveToFirst()) {
            int qty = c.getInt(2) + 1;
            db.execSQL("UPDATE cart SET qty=? WHERE name=?", new Object[]{qty, name});
        } else {
            ContentValues cv = new ContentValues();
            cv.put("name", name);
            cv.put("price", price);
            cv.put("qty", 1);
            db.insert("cart", null, cv);
        }

        c.close();
    }

    public Cursor getCart() {
        return getReadableDatabase().rawQuery("SELECT * FROM cart", null);
    }

    public int getCount() {
        Cursor c = getReadableDatabase().rawQuery("SELECT SUM(qty) FROM cart", null);
        int count = 0;
        if (c.moveToFirst()) count = c.getInt(0);
        c.close();
        return count;
    }
}
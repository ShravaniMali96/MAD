package com.example.fooddelivery;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class OrderSuccessActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_order_success);
    }

    public void goHome(View v) {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
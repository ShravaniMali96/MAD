package com.example.fooddelivery;

public class FoodItem {
    String name;
    int price;

    public FoodItem(String name, int price) {
        this.name = name;
        this.price = price;
    }
}